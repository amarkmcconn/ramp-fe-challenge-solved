import { Employee } from "./types"

export const EMPTY_EMPLOYEE: Employee = {
  id: "",
  firstName: "All",
  lastName: "Employees",
}
